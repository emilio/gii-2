#ifndef __TIPOELEMENTO_H
#define __TIPOELEMENTO_H

typedef int tipoElemento;


char compara(tipoElemento a, tipoElemento b);

#endif